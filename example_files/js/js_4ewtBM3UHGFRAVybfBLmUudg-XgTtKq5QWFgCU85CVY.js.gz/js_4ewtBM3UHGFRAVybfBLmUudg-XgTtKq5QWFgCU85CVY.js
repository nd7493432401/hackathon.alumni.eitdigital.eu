/* Source and licensing information for the line(s) below can be found at http://alumni.docker.localhost:8000/core/modules/media/js/media_embed_ckeditor.theme.js. */
(function(Drupal){Drupal.theme.mediaEmbedPreviewError=function(){return'<div>'+Drupal.t('An error occurred while trying to preview the media. Please save your work and reload this page.')+'</div>'};Drupal.theme.mediaEmbedEditButton=function(){return'<button class="media-library-item__edit">'+Drupal.t('Edit media')+'</button>'}})(Drupal)
/* Source and licensing information for the above line(s) can be found at http://alumni.docker.localhost:8000/core/modules/media/js/media_embed_ckeditor.theme.js. */;
/* Source and licensing information for the line(s) below can be found at http://alumni.docker.localhost:8000/core/modules/editor/js/editor.dialog.js. */
(function($,Drupal){Drupal.AjaxCommands.prototype.editorDialogSave=function(ajax,response,status){$(window).trigger('editor:dialogsave',[response.values])}})(jQuery,Drupal)
/* Source and licensing information for the above line(s) can be found at http://alumni.docker.localhost:8000/core/modules/editor/js/editor.dialog.js. */;
